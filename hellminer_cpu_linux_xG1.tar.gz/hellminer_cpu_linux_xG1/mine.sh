./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RVBJoZzMibtfCAx8AVrGXAzWa6jxxjQHXc.G1 -p x --cpu 2
